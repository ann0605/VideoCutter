
public class eleven {
	public static void main(String[] args){
		System.out.println(312032486 + (365*24*60*60)/7.0 - (365*24*60*60)/13.0 + (365*24*60*60)/45.0);
		//note to self: how to limit the number of decimals?
	}

}
