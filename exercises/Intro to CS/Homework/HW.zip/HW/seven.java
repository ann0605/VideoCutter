
public class seven {
	public static void main(String[] args){
		System.out.println(4*(1.0 - (1/3) + (1/5) - (1/7) + (1/9) - (1/11)));
	}
}
