
public class five {
	public static void main(String[] args){
		System.out.println((9.5*4.5-2.5*3)/(45.5-3.5));
	}
}
