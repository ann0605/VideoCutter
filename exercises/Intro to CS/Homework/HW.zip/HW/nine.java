public class nine {
	public static void main(String[] args){
		System.out.println("area is " + (4.5*7.9));
	}

}
