package finalReview2;

public class number12  {
	public static void main(String[] args){
		
	}
	
	try {
		int answer = 5/0;
	}
	catch 
}
