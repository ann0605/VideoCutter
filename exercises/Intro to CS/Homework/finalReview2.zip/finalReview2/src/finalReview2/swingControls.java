package finalReview2;

import javax.swing.JFrame;
//
//public class swingControls {
//	public static void main(String[] args){
//		JFrame f = newJframe("First Frame");
//		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		JPanel p = new JPanel();
//		f.add(p);
//		p.setLayout(null); //don't have to worry about the screen fit for now
//		JButton firstButton = new JButton();
//		
//	}
//}
///too lazy to type the rest

