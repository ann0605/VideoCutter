package finalReview2;

public class inheritanceReview {
//what is dynamic binding?
//13.6, 13.9, 13.10 --> look at ComparableRectangle

	
}
