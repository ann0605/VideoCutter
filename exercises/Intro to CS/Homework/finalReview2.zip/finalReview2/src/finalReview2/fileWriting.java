package finalReview2;

public class fileWriting {
	public static void main(String[] args){
		//writing
		File a = newFile("src/data/text1.txt");
		PrintWriter writer = new PrintWriter(a);
		
		writer.println("Hi There!");
		writer.println("What's up!");
	//appending to a file
		FileWriter fw = new FileWriter(a, true);//what does this mean
		PrintWriter writer = new PrintWRiter 
		
		
	}
}
