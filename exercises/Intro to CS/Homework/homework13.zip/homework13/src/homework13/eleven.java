package homework13;

public class eleven {
	public static void main(String[] args){
		Octagon shape = new Octagon(5);
		Octagon clonedShape = (Octagon) shape.clone();
	}
}
