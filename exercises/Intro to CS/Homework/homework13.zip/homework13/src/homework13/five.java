package homework13;

public class five {
	public static void main(String[] args){
		ComparableGO go = new ComparableGO();
		
	}

}
