package homework13;

public interface clonableOct {

}
