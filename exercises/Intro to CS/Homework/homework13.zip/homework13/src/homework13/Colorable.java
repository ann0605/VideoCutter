package homework13;
//http://www.dreamincode.net/forums/topic/245589-abstract-classes/
public interface Colorable {
	public void howToColor();
	}

