package classes;
import java.util.Random;
public class hw7 {
	public static void main(String[] args){
	Car [] cars = new Car[10]; // array with 10 cars
	String colors[] = { "blue", "red", "white", "yellow"};
	String makes[] = {"BMW", "Jaguar", "Bentley", "Toyota"};
	Random r =  new Random(123);
	for (int count = 0; count<cars.length-1; count++){
		cars[count].setColor(colors[r.nextInt(3)]);
		cars[count].setMake(makes[r.nextInt(3)]);
		cars[count].setSpeed(0);
	}
	for (int i= 0; i<(cars.length)/2; i++){
		cars[i].setYear(r.nextInt(9)+2000);
	}
	for (int i = (cars.length)/2; i<cars.length; i++){
		cars[i].setYear(r.nextInt(100)+2010);
	}
	for (int i = 0; i<100; i++){
		int flag = r.nextInt(3);
		if (flag == 1)
			cars[i].accelerate();
		else if(flag == 2)
			cars[i].brake();
		else 
			cars[i].stop();
	}
	for (int count = 0; count< cars.length; count++){
		System.out.print(cars[count].getColor());
		System.out.print(cars[count].getMake());
		System.out.print(cars[count].getSpeed());
		System.out.print(cars[count].getYear());
		
	}
	}

}
